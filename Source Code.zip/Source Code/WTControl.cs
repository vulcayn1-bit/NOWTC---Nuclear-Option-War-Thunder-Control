﻿using System;
using System.IO;
using System.Globalization;
using System.Collections.Generic;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace NOWTC
{
	[BepInPlugin("NoriYang.WTControl", "WTControl", "0.4.1")]
	public class WTControl : BaseUnityPlugin
	{
		private static string ConfigPath
		{
			get
			{
				return Path.Combine(Paths.PluginPath, "WTControl", "WTConfig.json");
			}
		}

		private static string PresetsPath
		{
			get
			{
				return Path.Combine(Paths.PluginPath, "WTControl", "Presets");
			}
		}

		// Configuration entries - Control Parameters
		private ConfigEntry<float> yaw2rollFactor;
		private ConfigEntry<float> yaw2rollLimit;
		private ConfigEntry<float> rollErrLimit;
		private ConfigEntry<float> pidPitchLimit;
		private ConfigEntry<float> pidYawLimit;
		private ConfigEntry<float> pidRollLimit;

		// Camera and cursor settings
		private ConfigEntry<float> cameraSensitivity;
		private ConfigEntry<float> cameraLagSpeed;
		private ConfigEntry<float> cursorMaxDistance;
		private ConfigEntry<bool> showAimCursor;
		private ConfigEntry<Color> cursorColor;
		private ConfigEntry<float> cursorSize;
		private ConfigEntry<float> cursorThickness;
		private ConfigEntry<float> cursorTransparency;
		private ConfigEntry<bool> showCenterDot;

		// Preset system
		private ConfigEntry<string> currentPresetName;
		private ConfigEntry<string> presetToLoad;
		private ConfigEntry<string> presetToSave;
		private ConfigEntry<string> presetToDelete;

		// Hotkeys
		private ConfigEntry<KeyboardShortcut> toggleControlKey;
		private ConfigEntry<KeyboardShortcut> reloadKey;
		private ConfigEntry<KeyboardShortcut> resetToDefaultKey;
		private ConfigEntry<KeyboardShortcut> savePresetKey;
		private ConfigEntry<KeyboardShortcut> loadPresetKey;

		internal static ManualLogSource Log;
		internal static bool IsControlEnabled = false;

		// Virtual cursor position
		internal static Vector2 VirtualCursorPos = Vector2.zero;
		internal static Vector2 MouseDelta = Vector2.zero;
		internal static bool ShowCursor = true;
		internal static Color CursorColor = new Color(1f, 1f, 0f, 0.8f);
		internal static float CursorSize = 20f;
		internal static float CursorThickness = 2f;
		internal static float CursorTransparency = 0.8f;
		internal static bool ShowCenterDot = true;
		internal static float CameraSensitivityValue = 1.5f;
		internal static float CursorMaxDistanceValue = 300f;

		private bool done;
		private bool togglePressed = false;
		private Texture2D cursorTexture;
		private List<string> availablePresets = new List<string>();
		private Vector3 lastMousePos;
		private CursorLockMode originalCursorMode;
		private bool originalCursorVisible;

		private void Awake()
		{
			Log = base.Logger;

			Directory.CreateDirectory(PresetsPath);

			// Initialize control parameters
			yaw2rollFactor = Config.Bind("Control Parameters", "Yaw to Roll Factor", 0.30f,
				new ConfigDescription("How much yaw input converts to roll (higher = more responsive turns)",
				new AcceptableValueRange<float>(0f, 1f)));

			yaw2rollLimit = Config.Bind("Control Parameters", "Yaw to Roll Limit", 38.0f,
				new ConfigDescription("Maximum roll angle from yaw input (degrees)",
				new AcceptableValueRange<float>(0f, 90f)));

			rollErrLimit = Config.Bind("Control Parameters", "Roll Error Limit", 3.2f,
				new ConfigDescription("Maximum roll error correction (degrees)",
				new AcceptableValueRange<float>(0f, 45f)));

			pidPitchLimit = Config.Bind("Control Parameters", "PID Pitch Limit", 0.38f,
				new ConfigDescription("Maximum pitch control authority from PID controller",
				new AcceptableValueRange<float>(0f, 1f)));

			pidYawLimit = Config.Bind("Control Parameters", "PID Yaw Limit", 0.18f,
				new ConfigDescription("Maximum yaw control authority from PID controller",
				new AcceptableValueRange<float>(0f, 1f)));

			pidRollLimit = Config.Bind("Control Parameters", "PID Roll Limit", 0.50f,
				new ConfigDescription("Maximum roll control authority from PID controller",
				new AcceptableValueRange<float>(0f, 1f)));

			// Camera and cursor settings
			cameraSensitivity = Config.Bind("Camera & Cursor", "Mouse Sensitivity", 1.5f,
				new ConfigDescription("How fast the cursor moves with mouse (War Thunder style)",
				new AcceptableValueRange<float>(0.1f, 5f)));

			cameraLagSpeed = Config.Bind("Camera & Cursor", "Camera Follow Speed", 2.5f,
				new ConfigDescription("How smoothly camera follows the cursor (higher = faster catch up)",
				new AcceptableValueRange<float>(0.5f, 10f)));

			cursorMaxDistance = Config.Bind("Camera & Cursor", "Max Cursor Distance", 300f,
				new ConfigDescription("Maximum distance cursor can move from screen center (pixels)",
				new AcceptableValueRange<float>(50f, 800f)));

			showAimCursor = Config.Bind("Crosshair Appearance", "Show Aim Cursor", true,
				"Display the War Thunder style aiming cursor on screen");

			cursorColor = Config.Bind("Crosshair Appearance", "Cursor Color", new Color(1f, 1f, 0f, 1f),
				"Color of the aiming cursor (RGB)");

			cursorSize = Config.Bind("Crosshair Appearance", "Cursor Size", 20f,
				new ConfigDescription("Diameter of the circle cursor",
				new AcceptableValueRange<float>(10f, 80f)));

			cursorThickness = Config.Bind("Crosshair Appearance", "Cursor Thickness", 2f,
				new ConfigDescription("Thickness of the circle line",
				new AcceptableValueRange<float>(1f, 8f)));

			cursorTransparency = Config.Bind("Crosshair Appearance", "Cursor Transparency", 0.8f,
				new ConfigDescription("Transparency of the cursor (0 = invisible, 1 = solid)",
				new AcceptableValueRange<float>(0f, 1f)));

			showCenterDot = Config.Bind("Crosshair Appearance", "Show Center Dot", true,
				"Show a dot in the center of the cursor");

			// Preset system
			RefreshPresetList();

			currentPresetName = Config.Bind("Preset System", "Current Preset", "Default",
				"Name of the currently active preset");

			presetToLoad = Config.Bind("Preset System", "Load Preset", "",
				new ConfigDescription($"Type preset name and press Enter to load. Available: {string.Join(", ", availablePresets)}"));

			presetToSave = Config.Bind("Preset System", "Save Preset As", "",
				"Type a name and press Enter to save current settings as a preset");

			presetToDelete = Config.Bind("Preset System", "Delete Preset", "",
				"Type preset name and press Enter to delete it");

			presetToLoad.SettingChanged += OnLoadPreset;
			presetToSave.SettingChanged += OnSavePreset;
			presetToDelete.SettingChanged += OnDeletePreset;

			// Hotkeys
			toggleControlKey = Config.Bind("Hotkeys", "Toggle WT Control",
				new KeyboardShortcut(KeyCode.T, KeyCode.LeftControl),
				"Toggle War Thunder style control ON/OFF");

			reloadKey = Config.Bind("Hotkeys", "Reload Parameters",
				new KeyboardShortcut(KeyCode.U, KeyCode.LeftControl),
				"Reload parameters from JSON file");

			resetToDefaultKey = Config.Bind("Hotkeys", "Reset to War Thunder Defaults",
				new KeyboardShortcut(KeyCode.R, KeyCode.LeftControl),
				"Reset all parameters to War Thunder-tuned defaults");

			savePresetKey = Config.Bind("Hotkeys", "Quick Save Preset",
				new KeyboardShortcut(KeyCode.F5),
				"Quick save current settings to 'QuickSave' preset");

			loadPresetKey = Config.Bind("Hotkeys", "Quick Load Preset",
				new KeyboardShortcut(KeyCode.F9),
				"Quick load the last saved 'QuickSave' preset");

			// Subscribe to config changes
			yaw2rollFactor.SettingChanged += OnSettingChanged;
			yaw2rollLimit.SettingChanged += OnSettingChanged;
			rollErrLimit.SettingChanged += OnSettingChanged;
			pidPitchLimit.SettingChanged += OnSettingChanged;
			pidYawLimit.SettingChanged += OnSettingChanged;
			pidRollLimit.SettingChanged += OnSettingChanged;
			cameraSensitivity.SettingChanged += OnSettingChanged;
			cameraLagSpeed.SettingChanged += OnSettingChanged;
			cursorMaxDistance.SettingChanged += OnSettingChanged;
			showAimCursor.SettingChanged += OnCursorSettingChanged;
			cursorColor.SettingChanged += OnCursorSettingChanged;
			cursorSize.SettingChanged += OnCursorSettingChanged;
			cursorThickness.SettingChanged += OnCursorSettingChanged;
			cursorTransparency.SettingChanged += OnCursorSettingChanged;
			showCenterDot.SettingChanged += OnCursorSettingChanged;

			UpdateParameters();
			UpdateCursorSettings();

			Harmony harmony = new Harmony("Norinco.WTControl");
			harmony.PatchAll();

			Log.LogInfo("WTControl v0.4.1 initialized");
			Log.LogInfo($"Press {toggleControlKey.Value} to toggle");
		}

		private void OnSettingChanged(object sender, EventArgs e)
		{
			UpdateParameters();
		}

		private void OnCursorSettingChanged(object sender, EventArgs e)
		{
			UpdateCursorSettings();
		}

		private void UpdateParameters()
		{
			TheWTControlThing.Params = new WTControlParameters
			{
				yaw2roll_factor = yaw2rollFactor.Value,
				yaw2roll_limit = yaw2rollLimit.Value,
				rollErr_limit = rollErrLimit.Value,
				PID_pitch_limit = pidPitchLimit.Value,
				PID_yaw_limit = pidYawLimit.Value,
				PID_roll_limit = pidRollLimit.Value
			};

			TheWTControlThing.CameraSensitivity = cameraSensitivity.Value;
			TheWTControlThing.CameraLagSpeed = cameraLagSpeed.Value;
			TheWTControlThing.CursorMaxDistance = cursorMaxDistance.Value;

			CameraSensitivityValue = cameraSensitivity.Value;
			CursorMaxDistanceValue = cursorMaxDistance.Value;
		}

		private void UpdateCursorSettings()
		{
			ShowCursor = showAimCursor.Value;
			CursorSize = cursorSize.Value;
			CursorThickness = cursorThickness.Value;
			CursorTransparency = cursorTransparency.Value;
			ShowCenterDot = showCenterDot.Value;

			Color baseColor = cursorColor.Value;
			CursorColor = new Color(baseColor.r, baseColor.g, baseColor.b, cursorTransparency.Value);
		}

		private void RefreshPresetList()
		{
			availablePresets.Clear();
			if (Directory.Exists(PresetsPath))
			{
				var presetFiles = Directory.GetFiles(PresetsPath, "*.preset");
				foreach (var file in presetFiles)
				{
					availablePresets.Add(Path.GetFileNameWithoutExtension(file));
				}
			}
		}

		private void OnLoadPreset(object sender, EventArgs e)
		{
			string presetName = presetToLoad.Value.Trim();
			if (!string.IsNullOrEmpty(presetName))
			{
				LoadPreset(presetName);
				presetToLoad.Value = "";
			}
		}

		private void OnSavePreset(object sender, EventArgs e)
		{
			string presetName = presetToSave.Value.Trim();
			if (!string.IsNullOrEmpty(presetName))
			{
				SavePreset(presetName);
				presetToSave.Value = "";
			}
		}

		private void OnDeletePreset(object sender, EventArgs e)
		{
			string presetName = presetToDelete.Value.Trim();
			if (!string.IsNullOrEmpty(presetName))
			{
				DeletePreset(presetName);
				presetToDelete.Value = "";
			}
		}

		private void SavePreset(string presetName)
		{
			try
			{
				string presetPath = Path.Combine(PresetsPath, presetName + ".preset");

				PresetData preset = new PresetData
				{
					yaw2roll_factor = yaw2rollFactor.Value,
					yaw2roll_limit = yaw2rollLimit.Value,
					rollErr_limit = rollErrLimit.Value,
					PID_pitch_limit = pidPitchLimit.Value,
					PID_yaw_limit = pidYawLimit.Value,
					PID_roll_limit = pidRollLimit.Value,
					cameraSensitivity = cameraSensitivity.Value,
					cameraLagSpeed = cameraLagSpeed.Value,
					cursorMaxDistance = cursorMaxDistance.Value,
					cursorSize = cursorSize.Value,
					cursorThickness = cursorThickness.Value,
					cursorTransparency = cursorTransparency.Value,
					showCenterDot = showCenterDot.Value,
					cursorColorR = cursorColor.Value.r,
					cursorColorG = cursorColor.Value.g,
					cursorColorB = cursorColor.Value.b
				};

				File.WriteAllText(presetPath, PresetToJson(preset));
				RefreshPresetList();
				currentPresetName.Value = presetName;
				Log.LogInfo($"Preset '{presetName}' saved!");
			}
			catch (Exception ex)
			{
				Log.LogError($"Failed to save preset: {ex.Message}");
			}
		}

		private void LoadPreset(string presetName)
		{
			try
			{
				string presetPath = Path.Combine(PresetsPath, presetName + ".preset");

				if (!File.Exists(presetPath))
				{
					Log.LogError($"Preset '{presetName}' not found!");
					return;
				}

				PresetData preset = JsonToPreset(File.ReadAllText(presetPath));

				yaw2rollFactor.Value = preset.yaw2roll_factor;
				yaw2rollLimit.Value = preset.yaw2roll_limit;
				rollErrLimit.Value = preset.rollErr_limit;
				pidPitchLimit.Value = preset.PID_pitch_limit;
				pidYawLimit.Value = preset.PID_yaw_limit;
				pidRollLimit.Value = preset.PID_roll_limit;
				cameraSensitivity.Value = preset.cameraSensitivity;
				cameraLagSpeed.Value = preset.cameraLagSpeed;
				cursorMaxDistance.Value = preset.cursorMaxDistance;
				cursorSize.Value = preset.cursorSize;
				cursorThickness.Value = preset.cursorThickness;
				cursorTransparency.Value = preset.cursorTransparency;
				showCenterDot.Value = preset.showCenterDot;
				cursorColor.Value = new Color(preset.cursorColorR, preset.cursorColorG, preset.cursorColorB);

				currentPresetName.Value = presetName;
				Log.LogInfo($"Preset '{presetName}' loaded!");
			}
			catch (Exception ex)
			{
				Log.LogError($"Failed to load preset: {ex.Message}");
			}
		}

		private void DeletePreset(string presetName)
		{
			try
			{
				string presetPath = Path.Combine(PresetsPath, presetName + ".preset");

				if (File.Exists(presetPath))
				{
					File.Delete(presetPath);
					RefreshPresetList();
					Log.LogInfo($"Preset '{presetName}' deleted!");
				}
				else
				{
					Log.LogError($"Preset '{presetName}' not found!");
				}
			}
			catch (Exception ex)
			{
				Log.LogError($"Failed to delete preset: {ex.Message}");
			}
		}

		private void Update()
		{
			// Toggle
			if (toggleControlKey.Value.IsDown() && !togglePressed)
			{
				IsControlEnabled = !IsControlEnabled;

				if (IsControlEnabled)
				{
					// Save original cursor state
					originalCursorMode = Cursor.lockState;
					originalCursorVisible = Cursor.visible;

					// Initialize cursor position at screen center
					VirtualCursorPos = new Vector2(Screen.width / 2f, Screen.height / 2f);
					lastMousePos = UnityEngine.Input.mousePosition;

					// Lock cursor for War Thunder mode
					Cursor.lockState = CursorLockMode.Locked;
					Cursor.visible = false;
				}
				else
				{
					// Restore original cursor state
					Cursor.lockState = originalCursorMode;
					Cursor.visible = originalCursorVisible;
				}

				Log.LogInfo($"WT Control: {(IsControlEnabled ? "ON" : "OFF")}");
				togglePressed = true;
			}
			else if (!toggleControlKey.Value.IsDown())
			{
				togglePressed = false;
			}

			// Update virtual cursor position when enabled
			if (IsControlEnabled)
			{
				// Get mouse delta
				Vector3 currentMousePos = UnityEngine.Input.mousePosition;
				Vector3 delta = currentMousePos - lastMousePos;
				lastMousePos = currentMousePos;

				// Store for use in patch
				MouseDelta = new Vector2(delta.x, delta.y);

				// Update virtual cursor
				VirtualCursorPos += MouseDelta * CameraSensitivityValue;

				// Clamp to max distance from center
				Vector2 screenCenter = new Vector2(Screen.width / 2f, Screen.height / 2f);
				Vector2 offset = VirtualCursorPos - screenCenter;

				if (offset.magnitude > CursorMaxDistanceValue)
				{
					offset = offset.normalized * CursorMaxDistanceValue;
					VirtualCursorPos = screenCenter + offset;
				}

				VirtualCursorPos.x = Mathf.Clamp(VirtualCursorPos.x, 0, Screen.width);
				VirtualCursorPos.y = Mathf.Clamp(VirtualCursorPos.y, 0, Screen.height);
			}

			// Quick save/load
			if (savePresetKey.Value.IsDown())
				SavePreset("QuickSave");

			if (loadPresetKey.Value.IsDown())
				LoadPreset("QuickSave");

			// Reload JSON
			if (reloadKey.Value.IsDown() && !done)
			{
				try
				{
					if (!File.Exists(ConfigPath))
					{
						Directory.CreateDirectory(Path.GetDirectoryName(ConfigPath));
						WriteJsonFile(ConfigPath, GetWarThunderDefaults());
					}

					WTControlParameters p = ReadJsonFile(ConfigPath);
					yaw2rollFactor.Value = p.yaw2roll_factor;
					yaw2rollLimit.Value = p.yaw2roll_limit;
					rollErrLimit.Value = p.rollErr_limit;
					pidPitchLimit.Value = p.PID_pitch_limit;
					pidYawLimit.Value = p.PID_yaw_limit;
					pidRollLimit.Value = p.PID_roll_limit;
					Log.LogInfo("Reloaded from JSON");
					done = true;
				}
				catch (Exception ex)
				{
					Log.LogError("Failed to load: " + ex);
				}
			}

			// Reset
			if (resetToDefaultKey.Value.IsDown())
			{
				WTControlParameters d = GetWarThunderDefaults();
				yaw2rollFactor.Value = d.yaw2roll_factor;
				yaw2rollLimit.Value = d.yaw2roll_limit;
				rollErrLimit.Value = d.rollErr_limit;
				pidPitchLimit.Value = d.PID_pitch_limit;
				pidYawLimit.Value = d.PID_yaw_limit;
				pidRollLimit.Value = d.PID_roll_limit;
				Log.LogInfo("Reset to defaults");
			}

			if (!reloadKey.Value.IsDown())
				done = false;
		}

		private void OnGUI()
		{
			if (!IsControlEnabled || !ShowCursor)
				return;

			DrawCircleCursor();
		}

		private void DrawCircleCursor()
		{
			float centerX = VirtualCursorPos.x;
			float centerY = Screen.height - VirtualCursorPos.y; // Flip Y for GUI coords
			float radius = CursorSize / 2f;

			if (cursorTexture == null)
			{
				cursorTexture = new Texture2D(1, 1);
				cursorTexture.SetPixel(0, 0, Color.white);
				cursorTexture.Apply();
			}

			GUI.color = CursorColor;

			// Draw circle
			int segments = 64;
			for (int i = 0; i < segments; i++)
			{
				float a1 = (i / (float)segments) * Mathf.PI * 2;
				float a2 = ((i + 1) / (float)segments) * Mathf.PI * 2;

				Vector2 p1 = new Vector2(centerX + Mathf.Cos(a1) * radius, centerY + Mathf.Sin(a1) * radius);
				Vector2 p2 = new Vector2(centerX + Mathf.Cos(a2) * radius, centerY + Mathf.Sin(a2) * radius);

				DrawLine(p1, p2, CursorThickness);
			}

			// Center dot
			if (ShowCenterDot)
			{
				float dotSize = Mathf.Max(3f, CursorThickness);
				GUI.DrawTexture(new Rect(centerX - dotSize / 2, centerY - dotSize / 2, dotSize, dotSize), cursorTexture);
			}

			GUI.color = Color.white;
		}

		private void DrawLine(Vector2 start, Vector2 end, float thickness)
		{
			Vector2 dir = end - start;
			float dist = dir.magnitude;
			float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;

			Matrix4x4 saved = GUI.matrix;
			GUIUtility.RotateAroundPivot(angle, start);
			GUI.DrawTexture(new Rect(start.x, start.y - thickness / 2, dist, thickness), cursorTexture);
			GUI.matrix = saved;
		}

		private WTControlParameters GetWarThunderDefaults()
		{
			return new WTControlParameters
			{
				yaw2roll_factor = 0.30f,
				yaw2roll_limit = 38.0f,
				rollErr_limit = 3.2f,
				PID_pitch_limit = 0.38f,
				PID_yaw_limit = 0.18f,
				PID_roll_limit = 0.50f
			};
		}

		private WTControlParameters ReadJsonFile(string path)
		{
			string json = File.ReadAllText(path);
			return new WTControlParameters
			{
				yaw2roll_factor = ParseJsonFloat(json, "yaw2roll_factor"),
				yaw2roll_limit = ParseJsonFloat(json, "yaw2roll_limit"),
				rollErr_limit = ParseJsonFloat(json, "rollErr_limit"),
				PID_pitch_limit = ParseJsonFloat(json, "PID_pitch_limit"),
				PID_yaw_limit = ParseJsonFloat(json, "PID_yaw_limit"),
				PID_roll_limit = ParseJsonFloat(json, "PID_roll_limit")
			};
		}

		private void WriteJsonFile(string path, WTControlParameters p)
		{
			string json = "{\n" +
				$"  \"yaw2roll_factor\": {p.yaw2roll_factor.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"yaw2roll_limit\": {p.yaw2roll_limit.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"rollErr_limit\": {p.rollErr_limit.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"PID_pitch_limit\": {p.PID_pitch_limit.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"PID_yaw_limit\": {p.PID_yaw_limit.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"PID_roll_limit\": {p.PID_roll_limit.ToString(CultureInfo.InvariantCulture)}\n";
			File.WriteAllText(path, json);
		}

		private float ParseJsonFloat(string json, string key)
		{
			int i = json.IndexOf("\"" + key + "\":");
			if (i == -1) return 0f;
			i += key.Length + 3;
			while (i < json.Length && char.IsWhiteSpace(json[i])) i++;
			int j = i;
			while (j < json.Length && json[j] != ',' && json[j] != '}') j++;
			return float.TryParse(json.Substring(i, j - i).Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float r) ? r : 0f;
		}

		private string PresetToJson(PresetData p)
		{
			return "{\n" +
				$"  \"yaw2roll_factor\": {p.yaw2roll_factor.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"yaw2roll_limit\": {p.yaw2roll_limit.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"rollErr_limit\": {p.rollErr_limit.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"PID_pitch_limit\": {p.PID_pitch_limit.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"PID_yaw_limit\": {p.PID_yaw_limit.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"PID_roll_limit\": {p.PID_roll_limit.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"cameraSensitivity\": {p.cameraSensitivity.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"cameraLagSpeed\": {p.cameraLagSpeed.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"cursorMaxDistance\": {p.cursorMaxDistance.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"cursorSize\": {p.cursorSize.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"cursorThickness\": {p.cursorThickness.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"cursorTransparency\": {p.cursorTransparency.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"showCenterDot\": {p.showCenterDot.ToString().ToLower()},\n" +
				$"  \"cursorColorR\": {p.cursorColorR.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"cursorColorG\": {p.cursorColorG.ToString(CultureInfo.InvariantCulture)},\n" +
				$"  \"cursorColorB\": {p.cursorColorB.ToString(CultureInfo.InvariantCulture)}\n";
		}

		private PresetData JsonToPreset(string json)
		{
			return new PresetData
			{
				yaw2roll_factor = ParseJsonFloat(json, "yaw2roll_factor"),
				yaw2roll_limit = ParseJsonFloat(json, "yaw2roll_limit"),
				rollErr_limit = ParseJsonFloat(json, "rollErr_limit"),
				PID_pitch_limit = ParseJsonFloat(json, "PID_pitch_limit"),
				PID_yaw_limit = ParseJsonFloat(json, "PID_yaw_limit"),
				PID_roll_limit = ParseJsonFloat(json, "PID_roll_limit"),
				cameraSensitivity = ParseJsonFloat(json, "cameraSensitivity"),
				cameraLagSpeed = ParseJsonFloat(json, "cameraLagSpeed"),
				cursorMaxDistance = ParseJsonFloat(json, "cursorMaxDistance"),
				cursorSize = ParseJsonFloat(json, "cursorSize"),
				cursorThickness = ParseJsonFloat(json, "cursorThickness"),
				cursorTransparency = ParseJsonFloat(json, "cursorTransparency"),
				showCenterDot = json.IndexOf("\"showCenterDot\": true") > 0,
				cursorColorR = ParseJsonFloat(json, "cursorColorR"),
				cursorColorG = ParseJsonFloat(json, "cursorColorG"),
				cursorColorB = ParseJsonFloat(json, "cursorColorB")
			};
		}

		private struct PresetData
		{
			public float yaw2roll_factor, yaw2roll_limit, rollErr_limit;
			public float PID_pitch_limit, PID_yaw_limit, PID_roll_limit;
			public float cameraSensitivity, cameraLagSpeed, cursorMaxDistance;
			public float cursorSize, cursorThickness, cursorTransparency;
			public bool showCenterDot;
			public float cursorColorR, cursorColorG, cursorColorB;
		}
	}
}
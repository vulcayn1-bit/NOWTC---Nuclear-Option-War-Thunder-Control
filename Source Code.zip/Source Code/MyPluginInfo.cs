﻿using System;

namespace NOWTC
{
	// Token: 0x02000004 RID: 4
	public static class MyPluginInfo
	{
		// Token: 0x04000002 RID: 2
		public const string PLUGIN_GUID = "NoriYang.WTControl";

		// Token: 0x04000003 RID: 3
		public const string PLUGIN_NAME = "WTControl";

		// Token: 0x04000004 RID: 4
		public const string PLUGIN_VERSION = "0.0.7";
	}
}

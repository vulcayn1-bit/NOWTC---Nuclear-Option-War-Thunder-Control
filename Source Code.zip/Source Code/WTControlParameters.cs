﻿using System;

namespace NOWTC
{
	public struct WTControlParameters
	{
		public static WTControlParameters Default
		{
			get
			{
				return new WTControlParameters
				{
					yaw2roll_factor = 0.30f,
					yaw2roll_limit = 38.0f,
					rollErr_limit = 3.2f,
					PID_pitch_limit = 0.38f,
					PID_yaw_limit = 0.18f,
					PID_roll_limit = 0.50f
				};
			}
		}

		public float yaw2roll_factor;
		public float yaw2roll_limit;
		public float rollErr_limit;
		public float PID_pitch_limit;
		public float PID_yaw_limit;
		public float PID_roll_limit;
	}
}
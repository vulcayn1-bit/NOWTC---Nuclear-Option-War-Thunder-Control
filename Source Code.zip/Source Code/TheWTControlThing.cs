﻿using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace NOWTC
{
	[HarmonyPatch(typeof(PilotPlayerState), "FixedUpdateState", new Type[] { typeof(Pilot) })]
	public static class TheWTControlThing
	{
		public static WTControlParameters Params = WTControlParameters.Default;
		public static float CameraSensitivity = 1.5f;
		public static float CameraLagSpeed = 2.5f;
		public static float CursorMaxDistance = 300f;

		private static readonly FieldInfo forwardFlightControllerField = typeof(Autopilot).GetField("forwardFlightController", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
		private static readonly FieldInfo controlInputsField = typeof(PilotPlayerState).GetField("controlInputs", BindingFlags.Instance | BindingFlags.NonPublic);
		private static readonly MethodInfo playerAxisControlsMethod = typeof(PilotPlayerState).GetMethod("PlayerAxisControls", BindingFlags.Instance | BindingFlags.NonPublic);

		public static bool Prefix(Pilot pilot, PilotPlayerState __instance)
		{
			// Check if WT Control is enabled
			if (!WTControl.IsControlEnabled)
			{
				return true; // Let normal controls run
			}

			// Only work in orbit camera mode
			if (CameraStateManager.cameraMode != CameraMode.orbit)
			{
				return true;
			}

			// Get player inputs
			playerAxisControlsMethod.Invoke(__instance, null);
			ControlInputs controlInputs = (ControlInputs)controlInputsField.GetValue(__instance);
			ControlInputs controlInputs2 = controlInputs;

			// Get autopilot component
			Autopilot component = pilot.aircraft.cockpit.GetComponent<Autopilot>();
			if (component == null)
			{
				return false;
			}

			object forwardController = forwardFlightControllerField.GetValue(component);
			if (forwardController == null)
			{
				return false;
			}

			// Update camera to follow virtual cursor (War Thunder style)
			UpdateCameraToFollowCursor(pilot);

			// Calculate angles between aircraft and camera direction
			Transform transform = pilot.aircraft.rb.transform;
			Camera main = Camera.main;
			Vector3 forward = transform.forward;
			Vector3 cameraForward = main.transform.forward;

			float angleOnAxis = TargetCalc.GetAngleOnAxis(forward, cameraForward, transform.right);
			float angleOnAxis2 = TargetCalc.GetAngleOnAxis(forward, cameraForward, transform.up);

			Transform xform = pilot.aircraft.cockpit.xform;

			// Calculate desired roll angle
			Vector3 other;
			if (Vector3.Dot(xform.forward, Vector3.up) > 0.25f)
			{
				other = Vector3.up;
			}
			else
			{
				float d = Mathf.Clamp(angleOnAxis2 * Params.yaw2roll_factor, -Params.yaw2roll_limit, Params.yaw2roll_limit);
				other = Vector3.up + d * xform.right;
			}

			float rollError = TargetCalc.GetAngleOnAxis(xform.up, other, -xform.forward);
			rollError = Mathf.Clamp(rollError, -Params.rollErr_limit, Params.rollErr_limit);

			Vector3 errorAngles = new Vector3(angleOnAxis, angleOnAxis2, rollError);
			float magnitude = pilot.aircraft.rb.velocity.magnitude;

			// Apply PID controller
			MethodInfo applyInputsMethod = forwardController.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public).First(delegate (MethodInfo m)
			{
				if (m.Name != "ApplyInputs")
				{
					return false;
				}

				ParameterInfo[] parameters = m.GetParameters();
				return (parameters.Length == 3 &&
						parameters[0].ParameterType == typeof(ControlInputs) &&
						parameters[1].ParameterType == typeof(float) &&
						parameters[2].ParameterType == typeof(Vector3));
			});

			applyInputsMethod.Invoke(forwardController, new object[] { controlInputs2, magnitude, errorAngles });

			// Clamp PID outputs
			controlInputs2.pitch = Mathf.Clamp(controlInputs2.pitch, -Params.PID_pitch_limit, Params.PID_pitch_limit);
			controlInputs2.roll = Mathf.Clamp(controlInputs2.roll, -Params.PID_roll_limit, Params.PID_roll_limit);
			controlInputs2.yaw = Mathf.Clamp(controlInputs2.yaw, -Params.PID_yaw_limit, Params.PID_yaw_limit);

			// Combine with player inputs
			controlInputs2.pitch = Mathf.Clamp(controlInputs2.pitch + controlInputs.pitch, -1f, 1f);
			controlInputs2.roll = Mathf.Clamp(controlInputs2.roll + controlInputs.roll, -1f, 1f);
			controlInputs2.yaw = Mathf.Clamp(controlInputs2.yaw + controlInputs.yaw, -1f, 1f);

			// Apply final inputs
			controlInputsField.SetValue(__instance, controlInputs2);
			pilot.aircraft.FilterInputs();

			return false;
		}

		private static void UpdateCameraToFollowCursor(Pilot pilot)
		{
			Camera main = Camera.main;
			if (main == null)
				return;

			// Get cursor offset from center
			Vector2 screenCenter = new Vector2(Screen.width / 2f, Screen.height / 2f);
			Vector2 cursorOffset = WTControl.VirtualCursorPos - screenCenter;

			// Convert screen offset to normalized values (-1 to 1)
			float horizontalNorm = (cursorOffset.x / (Screen.width / 2f));
			float verticalNorm = -(cursorOffset.y / (Screen.height / 2f)); // Negative because screen Y is inverted

			// Get current camera direction
			Vector3 aircraftPos = pilot.aircraft.rb.transform.position;
			Vector3 cameraPos = main.transform.position;

			// Calculate target direction based on cursor position
			// Use camera's local space to create the offset
			Vector3 rightOffset = main.transform.right * horizontalNorm * 30f;
			Vector3 upOffset = main.transform.up * verticalNorm * 30f;

			// Target point is aircraft position plus cursor-based offset
			Vector3 targetLookPoint = aircraftPos + rightOffset + upOffset;

			// Calculate direction from camera to target point
			Vector3 targetDirection = (targetLookPoint - cameraPos).normalized;

			// Smoothly rotate camera towards target direction
			Vector3 currentDirection = main.transform.forward;
			Vector3 newDirection = Vector3.Slerp(currentDirection, targetDirection, Time.fixedDeltaTime * CameraLagSpeed);

			// Apply rotation
			main.transform.rotation = Quaternion.LookRotation(newDirection);
		}
	}
}